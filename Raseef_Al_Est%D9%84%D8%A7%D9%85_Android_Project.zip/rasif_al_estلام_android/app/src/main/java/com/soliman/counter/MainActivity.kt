package com.soliman.counter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

// معامل الصندوق يبدأ بصفر حتى يدخله المستخدم بنفسه.
data class Product(var name: String, var factor: Double = 0.0, var boxes: Double = 0.0)

class MainActivity : Activity() {
    private val products = mutableListOf<Product>()
    private lateinit var list: LinearLayout
    private lateinit var totals: TextView
    private var tallyOnly = false
    private val prefs by lazy { getSharedPreferences("raseef_data", MODE_PRIVATE) }

    // الأصناف الـ54 مأخوذة من ورقة "التقفيل" في ملف الإكسيل المرسل.
    private val defaultNames = listOf(
        "بروكلي", "بروكلي تصدير", "بروكلي 1 قطعة - فروتوبيديا",
        "بصل أبيض مقشر", "بصل أحمر مقشر", "بقدونس", "بقدونس 100 جم - فروتوبيديا",
        "بنجر", "بنجر 1 ك - فروتوبيديا", "جرجير", "جرجير 100 جم - فروتوبيديا",
        "خس احمر", "خس احمر تصدير", "خس اخضر تصدير", "خس اخضر ماركت", "خس بلدي",
        "خس روماني", "خس روماني 1 قطعة - فروتوبيديا", "خس صيني (عدد)", "خس كابوتشا (عدد)",
        "خس كابوتشا 1 قطعة - فروتوبيديا", "خس لولاروسو", "خس لولو بيوندا 1 قطعة - فروتوبيديا",
        "خس لولو روسو 1 قطعة - فروتوبيديا", "خس لولوبيندا", "روزمارى", "ريحان", "زعتر",
        "سبانخ", "سبانخ 500 جم - فروتوبيديا", "سلق", "شبت", "شبت 100 جم - فروتوبيديا",
        "فجل ابيض ماركت", "فجل احمر ماركت", "قرنبيط", "قرنبيط تصدير", "كرات", "كرات بلدي",
        "كرفس", "كرفس فرنساوي تصدير", "كرفس 250 جم - فروتوبيديا", "كرنب احمر", "كرنب بلدي",
        "كرنب سلطه", "كرنب سلطه ماركت", "كزنب أبيض", "كزنب أحمر", "كزنب ساطه", "كسبرة",
        "كسبرة 100 جم - فروتوبيديا", "ليمون جروس", "نعناع", "نعناع 100 جم - فروتوبيديا"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        buildScreen()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 16f): TextView = TextView(this).apply {
        text = s; textSize = size; gravity = Gravity.CENTER; setTextColor(0xFF38291F.toInt())
        setPadding(dp(5), dp(5), dp(5), dp(5))
    }
    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; setOnClickListener { action() }
    }
    private fun field(hintText: String, value: String = "") = EditText(this).apply {
        hint = hintText; setText(value); textSize = 14f; setSingleLine(true)
        setPadding(dp(5), dp(6), dp(5), dp(6))
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(6), dp(10), dp(6))
            setBackgroundColor(0xFFF7F3EE.toInt())
        }
        outer.addView(label("رصيف الاستلام", 25f))
        outer.addView(label("اكتب العدد داخل الصندوق وعدد الصناديق لكل صنف", 13f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(button("إضافة صنف") { editProduct(null) }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button(if (tallyOnly) "عرض الكل" else "إظهار التقفيل") {
            tallyOnly = !tallyOnly; refresh()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button("PDF") { exportPdf() }, LinearLayout.LayoutParams(0, -2, 1f))
        outer.addView(actions)
        outer.addView(label("الصنف  |  داخل الصندوق  |  الصناديق  |  الكمية", 12f))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        totals = label("")
        outer.addView(totals)
        setContentView(outer)
        refresh()
    }

    private fun numberField(hint: String, value: Double, onSave: (Double) -> Unit): EditText {
        return field(hint, if (value == 0.0) "" else fmt(value)).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            gravity = Gravity.CENTER
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val entered = text.toString().trim().toDoubleOrNull() ?: 0.0
                    onSave(entered.coerceAtLeast(0.0))
                    save()
                    refresh()
                }
            }
        }
    }

    private fun refresh() {
        list.removeAllViews()
        products.forEachIndexed { index, p ->
            if (tallyOnly && p.boxes == 0.0) return@forEachIndexed
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(5), dp(4), dp(5))
            }
            val name = TextView(this).apply {
                text = p.name; textSize = 15f; setTextColor(0xFF38291F.toInt())
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                setPadding(dp(5), dp(3), dp(5), dp(3))
            }
            card.addView(name)
            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            }
            val factor = numberField("داخل الصندوق", p.factor) { p.factor = it }
            controls.addView(factor, LinearLayout.LayoutParams(0, dp(48), 1.15f))
            val boxes = numberField("الصناديق", p.boxes) { p.boxes = it }
            controls.addView(boxes, LinearLayout.LayoutParams(0, dp(48), 1f))
            controls.addView(label(fmt(p.boxes * p.factor), 14f), LinearLayout.LayoutParams(0, dp(48), 0.85f))
            card.addView(controls)
            card.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle(p.name)
                    .setItems(arrayOf("تعديل اسم الصنف", "حذف الصنف")) { _, which ->
                        if (which == 0) editProduct(index) else {
                            products.removeAt(index); save(); refresh()
                        }
                    }.show()
                true
            }
            list.addView(card)
            val divider = View(this).apply { setBackgroundColor(0xFFD8C9BA.toInt()) }
            list.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
        val boxTotal = products.sumOf { it.boxes }
        val qtyTotal = products.sumOf { it.boxes * it.factor }
        totals.text = "إجمالي الصناديق: ${fmt(boxTotal)}     إجمالي الكميات: ${fmt(qtyTotal)}"
    }

    private fun editProduct(index: Int?) {
        val old = index?.let { products[it] }
        val name = field("اسم الصنف", old?.name ?: "")
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8))
            addView(name)
        }
        AlertDialog.Builder(this).setTitle(if (old == null) "إضافة صنف" else "تعديل صنف")
            .setView(panel).setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isNotEmpty()) {
                    if (old == null) products.add(Product(n)) else old.name = n
                    save(); refresh()
                } else Toast.makeText(this, "اكتب اسم الصنف", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun fmt(v: Double) = if (v % 1.0 == 0.0) v.toLong().toString() else String.format("%.2f", v)

    private fun save() {
        val arr = JSONArray()
        products.forEach { p ->
            arr.put(JSONObject().put("name", p.name).put("factor", p.factor).put("boxes", p.boxes))
        }
        prefs.edit().putString("products", arr.toString()).apply()
    }

    private fun load() {
        val raw = prefs.getString("products", null)
        if (raw.isNullOrBlank()) {
            products.clear()
            defaultNames.forEach { products.add(Product(it)) }
            save()
            return
        }
        try {
            val arr = JSONArray(raw)
            if (arr.length() == 0) {
                defaultNames.forEach { products.add(Product(it)) }
                save()
            } else {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    products.add(Product(o.getString("name"), o.optDouble("factor", 0.0), o.optDouble("boxes", 0.0)))
                }
            }
        } catch (_: Exception) {
            products.clear()
            defaultNames.forEach { products.add(Product(it)) }
            save()
        }
    }

    private val CREATE_PDF = 4102
    private var pendingPdf: ByteArray? = null

    private fun exportPdf() {
        val selected = products.filter { it.boxes != 0.0 }
        if (selected.isEmpty()) {
            Toast.makeText(this, "لا توجد أصناف مسجلة في التقفيل", Toast.LENGTH_SHORT).show()
            return
        }
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas: Canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 18f; color = android.graphics.Color.BLACK; textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("رصيف الاستلام", 555f, 48f, paint)
        paint.textSize = 14f
        canvas.drawText("الصنف", 555f, 95f, paint)
        canvas.drawText("داخل الصندوق", 390f, 95f, paint)
        canvas.drawText("عدد الصناديق", 245f, 95f, paint)
        canvas.drawText("الكمية", 100f, 95f, paint)
        var y = 130f
        selected.forEach { p ->
            canvas.drawText(p.name.take(25), 555f, y, paint)
            canvas.drawText(fmt(p.factor), 390f, y, paint)
            canvas.drawText(fmt(p.boxes), 245f, y, paint)
            canvas.drawText(fmt(p.boxes * p.factor), 100f, y, paint)
            y += 28f
        }
        canvas.drawText("إجمالي الصناديق: ${fmt(selected.sumOf { it.boxes })}", 555f, y + 30f, paint)
        canvas.drawText("إجمالي الكميات: ${fmt(selected.sumOf { it.boxes * it.factor })}", 555f, y + 58f, paint)
        doc.finishPage(page)
        try {
            val output = java.io.ByteArrayOutputStream()
            doc.writeTo(output)
            pendingPdf = output.toByteArray()
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/pdf"
                putExtra(Intent.EXTRA_TITLE, "تقفيل-رصيف-الاستلام.pdf")
            }
            startActivityForResult(intent, CREATE_PDF)
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر تجهيز ملف PDF", Toast.LENGTH_SHORT).show()
        } finally { doc.close() }
    }

    @Deprecated("Android document picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CREATE_PDF && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            val bytes = pendingPdf
            if (uri != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    Toast.makeText(this, "تم حفظ ملف PDF بنجاح", Toast.LENGTH_LONG).show()
                } catch (_: Exception) {
                    Toast.makeText(this, "تعذر حفظ ملف PDF", Toast.LENGTH_SHORT).show()
                }
            }
        }
        pendingPdf = null
    }
}
