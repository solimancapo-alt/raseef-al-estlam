package com.soliman.counter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.MenuItem
import android.text.Editable
import android.text.TextWatcher
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.Layout
import android.text.TextPaint
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

// معامل الصندوق يبدأ بصفر حتى يدخله المستخدم بنفسه.
data class Product(var name: String, var factor: Double = 0.0, var boxes: Double = 0.0)

class MainActivity : Activity() {
    private val products = mutableListOf<Product>()
    private lateinit var list: LinearLayout
    private lateinit var totals: TextView
    private lateinit var showButton: Button
    private lateinit var searchField: EditText
    private var searchQuery = ""
    private var tallyOnly = false
    private var darkMode = false
    private val prefs by lazy { getSharedPreferences("raseef_data", MODE_PRIVATE) }

    // الأصناف الـ54 مأخوذة من ورقة "التقفيل" في ملف الإكسيل المرسل.
    private val defaultNames = listOf(
        "بروكلي", "بروكلي تصدير", "بروكلي 1 قطعة - فروتوبيديا",
        "بصل أبيض مقشر", "بصل أحمر مقشر", "بقدونس", "بقدونس 100 جم - فروتوبيديا",
        "بنجر", "بنجر 1 ك - فروتوبيديا", "جرجير", "جرجير 100 جم - فروتوبيديا",
        "خس احمر", "خس احمر تصدير", "خس اخضر تصدير", "خس اخضر ماركت", "خس بلدي",
        "خس روماني", "خس روماني 1 قطعة - فروتوبيديا", "خس صيني (عدد)", "خس كابوتشا (عدد)",
        "خس كابوتشا 1 قطعة - فروتوبيديا", "خس لولاروسو", "خس لولو بيوندا 1 قطعة - فروتوبيديا",
        "خس لولو روسو 1 قطعة - فروتوبيديا", "خس لولوبيندا", "روزمارى", "ريحان", "زعتر",
        "سبانخ", "سبانخ 500 جم - فروتوبيديا", "سلق", "شبت", "شبت 100 جم - فروتوبيديا",
        "فجل ابيض ماركت", "فجل احمر ماركت", "قرنبيط", "قرنبيط تصدير", "كرات", "كرات بلدي",
        "كرفس", "كرفس فرنساوي تصدير", "كرفس 250 جم - فروتوبيديا", "كرنب احمر", "كرنب بلدي",
        "كرنب سلطه", "كرنب سلطه ماركت", "كزنب أبيض", "كزنب أحمر", "كزنب ساطه", "كسبرة",
        "كسبرة 100 جم - فروتوبيديا", "ليمون جروس", "نعناع", "نعناع 100 جم - فروتوبيديا"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        darkMode = prefs.getBoolean("dark_mode", false)
        window.addFlags(if (prefs.getBoolean("keep_awake", false)) android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0)
        buildScreen()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun screenBg() = if (darkMode) 0xFF111111.toInt() else 0xFFF4F0E8.toInt()
    private fun primaryText() = if (darkMode) 0xFFF7F7F7.toInt() else 0xFF171717.toInt()
    private fun secondaryText() = if (darkMode) 0xFFB8C18A.toInt() else 0xFF75804B.toInt()
    private fun rowDivider() = if (darkMode) 0xFF454545.toInt() else 0xFFD2CEC6.toInt()
    private fun inputBg() = if (darkMode) 0xFF353535.toInt() else 0xFFFFFFFF.toInt()

    private fun roundedBackground(color: Int, strokeColor: Int, strokeWidth: Int = 1) =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color); cornerRadius = dp(13).toFloat()
            setStroke(dp(strokeWidth), strokeColor)
        }

    private fun label(s: String, size: Float = 16f): TextView = TextView(this).apply {
        text = s; textSize = size; gravity = Gravity.CENTER; setTextColor(primaryText())
        setPadding(dp(5), dp(5), dp(5), dp(5))
    }
    private fun button(s: String, action: () -> Unit, outlined: Boolean = false) = Button(this).apply {
        text = s; textSize = 16f; isAllCaps = false
        setTextColor(if (outlined) secondaryText() else 0xFFFFFFFF.toInt())
        background = if (outlined) roundedBackground(screenBg(), secondaryText(), 2)
            else roundedBackground(0xFF71864A.toInt(), 0xFF71864A.toInt(), 1)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { action() }
    }
    private fun field(hintText: String, value: String = "") = EditText(this).apply {
        hint = hintText; setText(value); textSize = 14f; setSingleLine(true)
        setTextColor(primaryText()); setHintTextColor(if (darkMode) 0xFFBDBDBD.toInt() else 0xFF888888.toInt())
        background = roundedBackground(inputBg(), if (darkMode) 0xFF555555.toInt() else 0xFFCCCCCC.toInt())
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(6), dp(14), dp(8))
            setBackgroundColor(screenBg())
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val backButton = TextView(this).apply {
            text = "‹"; textSize = 38f; gravity = Gravity.CENTER; setTextColor(primaryText())
            setOnClickListener { onBackPressed() }
        }
        top.addView(backButton, LinearLayout.LayoutParams(dp(42), dp(54)))
        top.addView(label("رصيف الاستلام", 23f), LinearLayout.LayoutParams(0, dp(54), 1f))
        val menuButton = TextView(this).apply {
            text = "⋮"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(primaryText())
            setPadding(dp(14), 0, dp(14), 0); contentDescription = "القائمة"
            setOnClickListener { showMainMenu(this) }
        }
        top.addView(menuButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        outer.addView(top)
        searchField = field("ابحث عن صنف...").apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            setCompoundDrawablePadding(dp(6))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s?.toString().orEmpty(); refresh() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        outer.addView(searchField, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10); bottomMargin = dp(8) })
        outer.addView(label("أدخل عدد الصناديق لكل صنف", 15f).apply { setTextColor(secondaryText()) })
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        header.addView(label("الإجمالي", 14f), LinearLayout.LayoutParams(0, dp(42), 0.75f))
        header.addView(label("عدد الصناديق", 14f), LinearLayout.LayoutParams(0, dp(42), 0.85f))
        header.addView(label("اسم الصنف", 14f), LinearLayout.LayoutParams(0, dp(42), 1.45f))
        outer.addView(header)
        outer.addView(View(this).apply { setBackgroundColor(rowDivider()) }, LinearLayout.LayoutParams(-1, dp(1)))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        totals = label("")
        outer.addView(totals)
        showButton = button(if (tallyOnly) "عرض الكل" else "إظهار التقفيل") {
            tallyOnly = !tallyOnly; refresh()
        }
        outer.addView(showButton, LinearLayout.LayoutParams(-1, -2))
        outer.addView(button("مسح أعداد التقفيل", ::confirmClearClosing, outlined = true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        applyAppearance(outer)
        setContentView(outer)
        refresh()
    }

    private fun showMainMenu(anchor: View) {
        val menu = android.widget.PopupMenu(this, anchor)
        menu.menu.add("تصدير PDF").setOnMenuItemClickListener { exportPdf(); true }
        menu.menu.add("إضافة صنف").setOnMenuItemClickListener { editProduct(null); true }
        menu.menu.add("تعديل صنف").setOnMenuItemClickListener { chooseProductToEdit(); true }
        menu.menu.add("الإعدادات").setOnMenuItemClickListener { showSettings(); true }
        menu.show()
    }

    private fun chooseProductToEdit() {
        if (products.isEmpty()) return
        AlertDialog.Builder(this).setTitle("اختر الصنف للتعديل")
            .setItems(products.map { it.name }.toTypedArray()) { _, which -> editProduct(which) }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun numberField(hint: String, value: Double, onSave: (Double) -> Unit): EditText {
        return field(hint, if (value == 0.0) "" else fmt(value)).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            gravity = Gravity.CENTER
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val entered = text.toString().trim().toDoubleOrNull() ?: 0.0
                    onSave(entered.coerceAtLeast(0.0))
                    save()
                    refresh()
                }
            }
        }
    }

    private fun refresh() {
        list.removeAllViews()
        products.forEachIndexed { index, p ->
            if (tallyOnly && p.boxes == 0.0) return@forEachIndexed
            if (searchQuery.isNotBlank() && !p.name.contains(searchQuery.trim(), ignoreCase = true)) return@forEachIndexed
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(dp(2), dp(4), dp(2), dp(4))
            }
            val name = TextView(this).apply {
                text = p.name; textSize = 14f; setTextColor(primaryText())
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                textDirection = View.TEXT_DIRECTION_RTL
                setPadding(dp(5), dp(3), dp(5), dp(3))
            }
            val totalForRow = label(fmt(p.boxes * p.factor), 14f)
            totalForRow.setTextColor(primaryText())
            val boxes = field("0", if (p.boxes == 0.0) "" else fmt(p.boxes)).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                gravity = Gravity.CENTER; textSize = 14f
                setTextColor(primaryText()); setHintTextColor(if (darkMode) 0xFFBDBDBD.toInt() else 0xFF777777.toInt())
                background = roundedBackground(inputBg(), if (darkMode) 0xFF555555.toInt() else 0xFFBDBDBD.toInt())
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        val v = s?.toString()?.toDoubleOrNull() ?: 0.0
                        p.boxes = v.coerceAtLeast(0.0)
                        totalForRow.text = fmt(p.boxes * p.factor)
                        updateTotalsOnly()
                        save()
                    }
                    override fun afterTextChanged(s: Editable?) {}
                })
            }
            // ترتيب العرض الفعلي من اليسار إلى اليمين: الإجمالي، عدد الصناديق، اسم الصنف.
            row.addView(totalForRow, LinearLayout.LayoutParams(0, dp(48), 0.75f))
            row.addView(boxes, LinearLayout.LayoutParams(0, dp(42), 0.85f).apply { setMargins(dp(3), 0, dp(3), 0) })
            row.addView(name, LinearLayout.LayoutParams(0, dp(48), 1.45f))
            row.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle(p.name)
                    .setItems(arrayOf("تعديل الصنف", "حذف الصنف")) { _, which ->
                        if (which == 0) editProduct(index) else confirmDelete(index)
                    }.show()
                true
            }
            list.addView(row)
            val divider = View(this).apply { setBackgroundColor(rowDivider()) }
            list.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
        updateTotalsOnly()
        updateShowButtonText()
    }

    private fun updateTotalsOnly() {
        if (::totals.isInitialized) {
            val boxTotal = products.sumOf { it.boxes }
            val qtyTotal = products.sumOf { it.boxes * it.factor }
            val completed = products.count { it.boxes > 0 }
            totals.text = "إجمالي الصناديق: ${fmt(boxTotal)}   إجمالي الكميات: ${fmt(qtyTotal)}\nالأصناف المكتملة: $completed / ${products.size}"
        }
    }

    private fun updateShowButtonText() {
        if (::showButton.isInitialized) showButton.text = if (tallyOnly) "عرض الكل" else "إظهار التقفيل"
    }

    private fun confirmClearClosing() {
        val count = products.count { it.boxes > 0 }
        if (count == 0) { Toast.makeText(this, "لا توجد أعداد لتصفيتها", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("مسح أعداد التقفيل")
            .setMessage("سيتم تصفير أعداد الكراتين لـ $count صنف. لن تتأثر أسماء الأصناف أو معاملات الصناديق. لا يمكن التراجع عن المسح. هل تريد المتابعة؟")
            .setPositiveButton("نعم، امسح التقفيل") { _, _ -> products.forEach { it.boxes = 0.0 }; tallyOnly = false; save(); refresh() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun showSettings() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        val dark = CheckBox(this).apply { text = "الوضع الداكن"; isChecked = darkMode }
        val awake = CheckBox(this).apply { text = "إبقاء الشاشة مضيئة أثناء العمل"; isChecked = prefs.getBoolean("keep_awake", false) }
        panel.addView(dark); panel.addView(awake)
        AlertDialog.Builder(this).setTitle("الإعدادات").setView(panel)
            .setPositiveButton("حفظ") { _, _ ->
                darkMode = dark.isChecked
                prefs.edit().putBoolean("dark_mode", darkMode).putBoolean("keep_awake", awake.isChecked).apply()
                if (awake.isChecked) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                buildScreen()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun applyAppearance(root: LinearLayout) {
        val bg = screenBg()
        val fg = primaryText()
        root.setBackgroundColor(bg)
        fun paint(view: android.view.View) {
            if (view is TextView) view.setTextColor(fg)
            if (view is LinearLayout) for (i in 0 until view.childCount) paint(view.getChildAt(i))
        }
        paint(root)
    }

    private fun confirmDelete(index: Int) {
        AlertDialog.Builder(this).setMessage("حذف الصنف من القائمة؟")
            .setPositiveButton("حذف") { _, _ -> products.removeAt(index); save(); refresh() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun editProduct(index: Int?) {
        val old = index?.let { products[it] }
        val name = field("اسم الصنف", old?.name ?: "")
        val factor = field("العدد داخل الصندوق", old?.factor?.let { if (it == 0.0) "" else fmt(it) } ?: "")
        factor.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8))
            addView(name); addView(factor)
        }
        AlertDialog.Builder(this).setTitle(if (old == null) "إضافة صنف" else "تعديل صنف")
            .setView(panel).setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim()
                val f = factor.text.toString().trim().toDoubleOrNull() ?: 0.0
                if (n.isNotEmpty() && f >= 0) {
                    if (old == null) products.add(Product(n, f)) else { old.name = n; old.factor = f }
                    save(); refresh()
                } else Toast.makeText(this, "راجع اسم الصنف والعدد داخل الصندوق", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun fmt(v: Double) = if (v % 1.0 == 0.0) v.toLong().toString() else String.format("%.2f", v)

    private fun save() {
        val arr = JSONArray()
        products.forEach { p ->
            arr.put(JSONObject().put("name", p.name).put("factor", p.factor).put("boxes", p.boxes))
        }
        prefs.edit().putString("products", arr.toString()).apply()
    }

    private fun normalizeName(value: String): String = value.trim().replace(Regex("\\s+"), " ")
        .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")

    // معاملات مستوردة من ملف الأصناف ذي الأربعين صنفًا؛ لا تستبدل أي قيمة أدخلها المستخدم سابقًا.
    private val importedFactors = mapOf(
        "سلق" to 5.0, "نعناع 100 جم - فروتوبيديا" to 20.0, "بروكلي" to 5.0,
        "بروكلي 1 قطعة - فروتوبيديا" to 8.0, "بصل أبيض مقشر" to 10.0,
        "بصل أحمر مقشر" to 10.0, "بقدونس" to 4.0, "بقدونس 100 جم - فروتوبيديا" to 20.0,
        "بنجر" to 10.0, "بنجر 1 ك - فروتوبيديا" to 10.0, "جرجير" to 4.0,
        "جرجير 100 جم - فروتوبيديا" to 20.0, "خس روماني" to 10.0,
        "خس روماني 1 قطعة - فروتوبيديا" to 10.0, "خس صيني (عدد)" to 5.0,
        "خس كابوتشا (عدد)" to 8.0, "خس كابوتشا 1 قطعة - فروتوبيديا" to 8.0,
        "خس لولوبيندا" to 4.0, "خس لولاروسو" to 4.0,
        "خس لولو بيوندا 1 قطعة - فروتوبيديا" to 8.0, "خس لولو روسو 1 قطعة - فروتوبيديا" to 8.0,
        "روزمارى" to 4.0, "ريحان" to 3.0, "زعتر" to 4.0, "سبانخ" to 5.0,
        "سبانخ 500 جم - فروتوبيديا" to 10.0, "شبت" to 4.0, "شبت 100 جم - فروتوبيديا" to 20.0,
        "قرنبيط" to 6.0, "كرات" to 5.0, "كرات بلدي" to 4.0, "كرفس" to 5.0,
        "كرفس 250 جم - فروتوبيديا" to 20.0, "كزنب أبيض" to 2.0, "كزنب أحمر" to 6.0,
        "كزنب ساطه" to 5.0, "كسبرة" to 4.0, "كسبرة 100 جم - فروتوبيديا" to 20.0,
        "ليمون جروس" to 5.0, "نعناع" to 3.0
    ).mapKeys { normalizeName(it.key) }

    private fun load() {
        val raw = prefs.getString("products", null)
        if (raw.isNullOrBlank()) {
            products.clear(); defaultNames.forEach { products.add(Product(it)) }
            applyImportedFactors(); save(); return
        }
        try {
            val arr = JSONArray(raw)
            if (arr.length() == 0) defaultNames.forEach { products.add(Product(it)) }
            else for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                products.add(Product(o.getString("name"), o.optDouble("factor", 0.0), o.optDouble("boxes", 0.0)))
            }
            // Migration v1.1 -> v1.2: preserve counts and all non-zero user factors.
            applyImportedFactors(); save()
        } catch (_: Exception) {
            products.clear(); defaultNames.forEach { products.add(Product(it)) }
            applyImportedFactors(); save()
        }
    }

    private fun applyImportedFactors() {
        products.forEach { p ->
            val imported = importedFactors[normalizeName(p.name)]
            if (p.factor == 0.0 && imported != null) p.factor = imported
        }
    }

    @Deprecated("Back navigation confirmation")
    override fun onBackPressed() {
        if (products.any { it.boxes > 0 }) {
            AlertDialog.Builder(this).setTitle("تقفيل غير ممسوح")
                .setMessage("يوجد تقفيل حالي. يمكنك حفظه PDF أو مسح أعداده من الزر المخصص. الخروج لن يمسح الأرقام، وستظل محفوظة عند فتح التطبيق مرة أخرى.")
                .setPositiveButton("خروج مع الاحتفاظ بالأرقام") { _, _ -> super.onBackPressed() }
                .setNegativeButton("البقاء في التطبيق", null).show()
        } else super.onBackPressed()
    }

    private val CREATE_PDF = 4102
    private var pendingPdf: ByteArray? = null

    private fun drawArabic(canvas: Canvas, value: String, right: Float, baseline: Float, width: Int, sourcePaint: Paint): Int {
        val tp = TextPaint(sourcePaint)
        val layout = StaticLayout.Builder.obtain(value, 0, value.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false).build()
        canvas.save()
        canvas.translate(right - width, baseline - layout.height + 4f)
        layout.draw(canvas)
        canvas.restore()
        return layout.height
    }

    private fun exportPdf() {
        val selected = products.filter { it.boxes != 0.0 }
        if (selected.isEmpty()) {
            Toast.makeText(this, "لا توجد أصناف مسجلة في التقفيل", Toast.LENGTH_SHORT).show(); return
        }
        val doc = PdfDocument()
        val pageWidth = 595; val pageHeight = 842
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textAlign = Paint.Align.RIGHT }
        val rowsPerPage = 17
        val chunks = selected.chunked(rowsPerPage)
        chunks.forEachIndexed { pageIndex, chunk ->
            val info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
            val page = doc.startPage(info); val canvas = page.canvas
            paint.textSize = 19f; drawArabic(canvas, "رصيف الاستلام", 555f, 42f, 240, paint)
            paint.textSize = 15f; drawArabic(canvas, "تقرير التقفيل", 555f, 66f, 240, paint)
            paint.textSize = 10f; drawArabic(canvas, java.text.SimpleDateFormat("yyyy/MM/dd  HH:mm", java.util.Locale("ar")).format(java.util.Date()), 555f, 82f, 240, paint)
            paint.textSize = 13f
            drawArabic(canvas, "الصنف", 555f, 92f, 150, paint); drawArabic(canvas, "داخل الصندوق", 390f, 92f, 110, paint)
            drawArabic(canvas, "عدد الصناديق", 245f, 92f, 110, paint); drawArabic(canvas, "الإجمالي", 100f, 92f, 80, paint)
            var y = 125f
            chunk.forEach { p ->
                paint.textSize = 11.5f
                val nameHeight = drawArabic(canvas, p.name, 555f, y, 150, paint)
                paint.textSize = 13f
                canvas.drawText(fmt(p.factor), 390f, y, paint)
                canvas.drawText(fmt(p.boxes), 245f, y, paint)
                canvas.drawText(fmt(p.boxes * p.factor), 100f, y, paint)
                y += maxOf(27f, nameHeight + 8f)
            }
            if (pageIndex == chunks.lastIndex) {
                y += 24f
                drawArabic(canvas, "إجمالي الصناديق: ${fmt(selected.sumOf { it.boxes })}", 555f, y, 300, paint)
                drawArabic(canvas, "إجمالي الكميات: ${fmt(selected.sumOf { it.boxes * it.factor })}", 555f, y + 28f, 300, paint)
            }
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText("${pageIndex + 1} / ${chunks.size}", 40f, 810f, paint)
            paint.textAlign = Paint.Align.RIGHT
            doc.finishPage(page)
        }
        try {
            val output = java.io.ByteArrayOutputStream(); doc.writeTo(output); pendingPdf = output.toByteArray()
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
                putExtra(Intent.EXTRA_TITLE, "تقفيل-رصيف-الاستلام.pdf")
            }
            startActivityForResult(intent, CREATE_PDF)
        } catch (_: Exception) { Toast.makeText(this, "تعذر تجهيز ملف PDF", Toast.LENGTH_SHORT).show() }
        finally { doc.close() }
    }

    @Deprecated("Android document picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CREATE_PDF && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            val bytes = pendingPdf
            if (uri != null && bytes != null) {
                try {
                    val stream = contentResolver.openOutputStream(uri) ?: throw java.io.IOException("تعذر فتح ملف الحفظ")
                    stream.use { it.write(bytes); it.flush() }
                    Toast.makeText(this, "تم حفظ ملف PDF بنجاح. أعداد التقفيل ما زالت محفوظة.", Toast.LENGTH_LONG).show()
                } catch (_: Exception) {
                    Toast.makeText(this, "تعذر حفظ ملف PDF", Toast.LENGTH_SHORT).show()
                }
            }
        }
        pendingPdf = null
    }
}
