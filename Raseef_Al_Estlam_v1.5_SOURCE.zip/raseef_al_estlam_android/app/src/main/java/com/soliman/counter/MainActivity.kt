package com.soliman.counter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.MenuItem
import android.text.Editable
import android.text.TextWatcher
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.Layout
import android.text.TextPaint
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

// معامل الصندوق يبدأ بصفر حتى يدخله المستخدم بنفسه.
data class Product(var name: String, var factor: Double = 0.0, var boxes: Double = 0.0, var unit: String = "قطعة")

class MainActivity : Activity() {
    private val products = mutableListOf<Product>()
    private lateinit var list: LinearLayout
    private lateinit var totals: TextView
    private lateinit var showButton: Button
    private lateinit var searchField: EditText
    private var searchQuery = ""
    private var tallyOnly = false
    private var darkMode = false
    private var savingReceipt = false
    private val retentionDays = 60L
    private val prefs by lazy { getSharedPreferences("raseef_data", MODE_PRIVATE) }

    // الأصناف الـ54 مأخوذة من ورقة "التقفيل" في ملف الإكسيل المرسل.
    private val defaultNames = listOf(
        "بروكلي", "بروكلي تصدير", "بروكلي 1 قطعة - فروتوبيديا",
        "بصل أبيض مقشر", "بصل أحمر مقشر", "بقدونس", "بقدونس 100 جم - فروتوبيديا",
        "بنجر", "بنجر 1 ك - فروتوبيديا", "جرجير", "جرجير 100 جم - فروتوبيديا",
        "خس احمر", "خس احمر تصدير", "خس اخضر تصدير", "خس اخضر ماركت", "خس بلدي",
        "خس روماني", "خس روماني 1 قطعة - فروتوبيديا", "خس صيني (عدد)", "خس كابوتشا (عدد)",
        "خس كابوتشا 1 قطعة - فروتوبيديا", "خس لولاروسو", "خس لولو بيوندا 1 قطعة - فروتوبيديا",
        "خس لولو روسو 1 قطعة - فروتوبيديا", "خس لولوبيندا", "روزمارى", "ريحان", "زعتر",
        "سبانخ", "سبانخ 500 جم - فروتوبيديا", "سلق", "شبت", "شبت 100 جم - فروتوبيديا",
        "فجل ابيض ماركت", "فجل احمر ماركت", "قرنبيط", "قرنبيط تصدير", "كرات", "كرات بلدي",
        "كرفس", "كرفس فرنساوي تصدير", "كرفس 250 جم - فروتوبيديا", "كرنب احمر", "كرنب بلدي",
        "كرنب سلطه", "كرنب سلطه ماركت", "كزنب أبيض", "كزنب أحمر", "كزنب ساطه", "كسبرة",
        "كسبرة 100 جم - فروتوبيديا", "ليمون جروس", "نعناع", "نعناع 100 جم - فروتوبيديا"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        darkMode = prefs.getBoolean("dark_mode", true)
        cleanExpiredReceipts()
        window.addFlags(if (prefs.getBoolean("keep_awake", false)) android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0)
        buildScreen()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun screenBg() = if (darkMode) 0xD9111111.toInt() else 0xDDF4F0E8.toInt()
    private fun primaryText() = if (darkMode) 0xFFF7F7F7.toInt() else 0xFF171717.toInt()
    private fun secondaryText() = if (darkMode) 0xFFB8C18A.toInt() else 0xFF75804B.toInt()
    private fun rowDivider() = if (darkMode) 0xFF454545.toInt() else 0xFFD2CEC6.toInt()
    private fun inputBg() = if (darkMode) 0xFF353535.toInt() else 0xFFFFFFFF.toInt()

    private fun roundedBackground(color: Int, strokeColor: Int, strokeWidth: Int = 1) =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color); cornerRadius = dp(13).toFloat()
            setStroke(dp(strokeWidth), strokeColor)
        }

    private fun label(s: String, size: Float = 16f): TextView = TextView(this).apply {
        text = s; textSize = size; gravity = Gravity.CENTER; setTextColor(primaryText())
        setPadding(dp(5), dp(5), dp(5), dp(5))
    }
    private fun button(s: String, action: () -> Unit, outlined: Boolean = false) = Button(this).apply {
        text = s; textSize = 16f; isAllCaps = false
        setTextColor(if (outlined) secondaryText() else 0xFFFFFFFF.toInt())
        background = if (outlined) roundedBackground(screenBg(), secondaryText(), 2)
            else roundedBackground(0xFF71864A.toInt(), 0xFF71864A.toInt(), 1)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { action() }
    }
    private fun field(hintText: String, value: String = "") = EditText(this).apply {
        hint = hintText; setText(value); textSize = 14f; setSingleLine(true)
        setTextColor(primaryText()); setHintTextColor(if (darkMode) 0xFFBDBDBD.toInt() else 0xFF888888.toInt())
        background = roundedBackground(inputBg(), if (darkMode) 0xFF555555.toInt() else 0xFFCCCCCC.toInt())
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(34), dp(14), dp(24))
            background = marketBackground()
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val backButton = TextView(this).apply {
            text = "‹"; textSize = 38f; gravity = Gravity.CENTER; setTextColor(primaryText())
            setOnClickListener { onBackPressed() }
        }
        top.addView(backButton, LinearLayout.LayoutParams(dp(42), dp(54)))
        top.addView(label("رصيف الاستلام", 23f), LinearLayout.LayoutParams(0, dp(54), 1f))
        val menuButton = TextView(this).apply {
            text = "⋮"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(primaryText())
            setPadding(dp(14), 0, dp(14), 0); contentDescription = "القائمة"
            setOnClickListener { showMainMenu(this) }
        }
        top.addView(menuButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        outer.addView(top)
        searchField = field("ابحث عن صنف...").apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            setCompoundDrawablePadding(dp(6))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s?.toString().orEmpty(); refresh() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        outer.addView(searchField, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10); bottomMargin = dp(8) })
        outer.addView(label("أدخل عدد الصناديق لكل صنف", 15f).apply { setTextColor(secondaryText()) })
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        header.addView(label("الإجمالي", 14f), LinearLayout.LayoutParams(0, dp(42), 0.75f))
        header.addView(label("عدد الصناديق", 14f), LinearLayout.LayoutParams(0, dp(42), 0.85f))
        header.addView(label("اسم الصنف", 14f), LinearLayout.LayoutParams(0, dp(42), 1.45f))
        outer.addView(header)
        outer.addView(View(this).apply { setBackgroundColor(rowDivider()) }, LinearLayout.LayoutParams(-1, dp(1)))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        totals = label("")
        outer.addView(totals)
        val saveReceiptButton = button("حفظ إيصال الاستلام", ::promptSaveReceipt).apply {
            background = roundedBackground(0xFFD8AD67.toInt(), 0xFFD8AD67.toInt(), 1)
            setTextColor(0xFF201A12.toInt())
        }
        outer.addView(saveReceiptButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
        showButton = button(if (tallyOnly) "عرض الكل" else "إظهار التقفيل", action = {
            tallyOnly = !tallyOnly; refresh()
        })
        outer.addView(showButton, LinearLayout.LayoutParams(-1, -2))
        outer.addView(button("مسح أعداد التقفيل", ::confirmClearClosing, outlined = true).apply {
            setTextColor(0xFFC95B51.toInt())
            background = roundedBackground(screenBg(), 0xFFC95B51.toInt(), 2)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val footerName = prefs.getString("report_name", "")?.trim().orEmpty()
        if (footerName.isNotBlank()) outer.addView(label("إعداد وتطوير: $footerName", 12f).apply { setTextColor(secondaryText()) })
        applyAppearance(outer)
        setContentView(outer)
        refresh()
    }

    private fun showMainMenu(anchor: View) {
        val menu = android.widget.PopupMenu(this, anchor)
        menu.menu.add("تصدير PDF").setOnMenuItemClickListener { exportPdf(); true }
        menu.menu.add("تصدير Excel").setOnMenuItemClickListener { exportExcel(); true }
        menu.menu.add("إضافة صنف").setOnMenuItemClickListener { editProduct(null); true }
        menu.menu.add("تعديل صنف").setOnMenuItemClickListener { chooseProductToEdit(); true }
        menu.menu.add("الإعدادات").setOnMenuItemClickListener { showSettings(); true }
        menu.show()
    }

    private fun chooseProductToEdit() {
        if (products.isEmpty()) return
        AlertDialog.Builder(this).setTitle("اختر الصنف للتعديل")
            .setItems(products.map { it.name }.toTypedArray()) { _, which -> editProduct(which) }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun numberField(hint: String, value: Double, onSave: (Double) -> Unit): EditText {
        return field(hint, if (value == 0.0) "" else fmt(value)).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            gravity = Gravity.CENTER
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val entered = text.toString().trim().toDoubleOrNull() ?: 0.0
                    onSave(entered.coerceAtLeast(0.0))
                    save()
                    refresh()
                }
            }
        }
    }

    private fun refresh() {
        list.removeAllViews()
        products.forEachIndexed { index, p ->
            if (tallyOnly && p.boxes == 0.0) return@forEachIndexed
            if (searchQuery.isNotBlank() && !p.name.contains(searchQuery.trim(), ignoreCase = true)) return@forEachIndexed
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(dp(2), dp(4), dp(2), dp(4))
            }
            val name = TextView(this).apply {
                text = p.name; textSize = 14f; setTextColor(primaryText())
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                textDirection = View.TEXT_DIRECTION_RTL
                setPadding(dp(5), dp(3), dp(5), dp(3))
            }
            val totalForRow = label("${fmt(p.boxes * p.factor)} ${p.unit}", 14f)
            totalForRow.setTextColor(primaryText())
            val boxes = field("0", if (p.boxes == 0.0) "" else fmt(p.boxes)).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                gravity = Gravity.CENTER; textSize = 14f
                setTextColor(primaryText()); setHintTextColor(if (darkMode) 0xFFBDBDBD.toInt() else 0xFF777777.toInt())
                background = roundedBackground(inputBg(), if (darkMode) 0xFF555555.toInt() else 0xFFBDBDBD.toInt())
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        val v = s?.toString()?.toDoubleOrNull() ?: 0.0
                        p.boxes = v.coerceAtLeast(0.0)
                        totalForRow.text = "${fmt(p.boxes * p.factor)} ${p.unit}"
                        updateTotalsOnly()
                        save()
                    }
                    override fun afterTextChanged(s: Editable?) {}
                })
            }
            // ترتيب العرض الفعلي من اليسار إلى اليمين: الإجمالي، عدد الصناديق، اسم الصنف.
            row.addView(totalForRow, LinearLayout.LayoutParams(0, dp(48), 0.75f))
            row.addView(boxes, LinearLayout.LayoutParams(0, dp(42), 0.85f).apply { setMargins(dp(3), 0, dp(3), 0) })
            row.addView(name, LinearLayout.LayoutParams(0, dp(48), 1.45f))
            row.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle(p.name)
                    .setItems(arrayOf("تعديل الصنف", "حذف الصنف")) { _, which ->
                        if (which == 0) editProduct(index) else confirmDelete(index)
                    }.show()
                true
            }
            list.addView(row)
            val divider = View(this).apply { setBackgroundColor(rowDivider()) }
            list.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
        updateTotalsOnly()
        updateShowButtonText()
    }

    private fun updateTotalsOnly() {
        if (::totals.isInitialized) {
            val boxTotal = products.sumOf { it.boxes }
            val pieceQty = products.filter { it.unit == "قطعة" }.sumOf { it.boxes * it.factor }
            val kgQty = products.filter { it.unit == "كجم" }.sumOf { it.boxes * it.factor }
            val completed = products.count { it.boxes > 0 }
            totals.text = "إجمالي الصناديق: ${fmt(boxTotal)}\nإجمالي القطع: ${fmt(pieceQty)} قطعة   |   إجمالي الوزن: ${fmt(kgQty)} كجم\nالأصناف المكتملة: $completed / ${products.size}"
        }
    }

    private fun updateShowButtonText() {
        if (::showButton.isInitialized) showButton.text = if (tallyOnly) "عرض الكل" else "إظهار التقفيل"
    }

    private fun confirmClearClosing() {
        val count = products.count { it.boxes > 0 }
        if (count == 0) { Toast.makeText(this, "لا توجد أعداد لتصفيتها", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("مسح أعداد التقفيل")
            .setMessage("سيتم تصفير أعداد الكراتين لـ $count صنف. لن تتأثر أسماء الأصناف أو معاملات الصناديق. لا يمكن التراجع عن المسح. هل تريد المتابعة؟")
            .setPositiveButton("نعم، امسح التقفيل") { _, _ -> products.forEach { it.boxes = 0.0 }; tallyOnly = false; save(); refresh() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun showSettings() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        val dark = CheckBox(this).apply { text = "الوضع الداكن"; isChecked = darkMode }
        val awake = CheckBox(this).apply { text = "إبقاء الشاشة مضيئة أثناء العمل"; isChecked = prefs.getBoolean("keep_awake", false) }
        val reportName = field("اسم معد التقرير", prefs.getString("report_name", "") ?: "")
        panel.addView(dark); panel.addView(awake)
        panel.addView(label("اسم معد التقرير", 14f).apply { setTextColor(Color.BLACK) }); panel.addView(reportName)
        panel.addView(label("مدة الاحتفاظ بإيصالات الاستلام: 60 يومًا", 13f).apply { setTextColor(Color.DKGRAY) })
        AlertDialog.Builder(this).setTitle("الإعدادات").setView(panel)
            .setPositiveButton("حفظ") { _, _ ->
                darkMode = dark.isChecked
                prefs.edit().putBoolean("dark_mode", darkMode).putBoolean("keep_awake", awake.isChecked)
                    .putString("report_name", reportName.text.toString().trim()).apply()
                if (awake.isChecked) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                buildScreen()
            }.setNeutralButton("إيصال استلام قديم") { _, _ -> showOldReceipts() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun marketBackground(): android.graphics.drawable.Drawable {
        return try {
            val bmp = BitmapFactory.decodeResource(resources, com.soliman.counter.R.drawable.market_background)
            BitmapDrawable(resources, bmp).apply { alpha = if (darkMode) 205 else 220 }
        } catch (_: Exception) { android.graphics.drawable.ColorDrawable(screenBg()) }
    }

    private fun cleanExpiredReceipts() {
        val now = System.currentTimeMillis()
        val arr = try { JSONArray(prefs.getString("old_receipts", "[]")) } catch (_: Exception) { JSONArray() }
        val keep = JSONArray()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            if (now - item.optLong("timestamp", 0L) < retentionDays * 24L * 60L * 60L * 1000L) keep.put(item)
        }
        prefs.edit().putString("old_receipts", keep.toString()).apply()
    }

    private fun promptSaveReceipt() {
        if (savingReceipt) return
        if (products.none { it.boxes > 0 }) { Toast.makeText(this, "لا توجد أصناف مسجلة للحفظ", Toast.LENGTH_SHORT).show(); return }
        val supplier = field("اكتب اسم المورد (إجباري)")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(4)); addView(label("اسم المورد", 14f).apply { setTextColor(Color.BLACK) }); addView(supplier) }
        val dialog = AlertDialog.Builder(this).setTitle("حفظ إيصال الاستلام").setView(box)
            .setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = supplier.text.toString().trim()
                if (name.isBlank()) { supplier.error = "اسم المورد مطلوب"; return@setOnClickListener }
                saveReceipt(name)
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun saveReceipt(supplier: String) {
        if (savingReceipt) return
        savingReceipt = true
        try {
            val arr = JSONArray(prefs.getString("old_receipts", "[]") ?: "[]")
            val rows = JSONArray()
            products.filter { it.boxes > 0 }.forEach { pr ->
                rows.put(JSONObject().put("name", pr.name).put("factor", pr.factor).put("boxes", pr.boxes).put("unit", pr.unit))
            }
            if (arr.length() > 0) {
                val last = arr.optJSONObject(arr.length() - 1)
                if (last != null && last.optString("supplier") == supplier &&
                    System.currentTimeMillis() - last.optLong("timestamp") < 5000L &&
                    (last.optJSONArray("rows")?.toString() ?: "") == rows.toString()) {
                    Toast.makeText(this, "تم حفظ نفس الإيصال بالفعل", Toast.LENGTH_SHORT).show()
                    return
                }
            }
            val receipt = JSONObject().put("supplier", supplier).put("timestamp", System.currentTimeMillis())
                .put("rows", rows).put("report_name", prefs.getString("report_name", "") ?: "")
            arr.put(receipt)
            prefs.edit().putString("old_receipts", arr.toString()).apply()
            Toast.makeText(this, "تم حفظ إيصال الاستلام باسم $supplier", Toast.LENGTH_LONG).show()
        } catch (_: Exception) { Toast.makeText(this, "تعذر حفظ الإيصال", Toast.LENGTH_SHORT).show() }
        finally { savingReceipt = false }
    }

    private fun showOldReceipts() {
        cleanExpiredReceipts()
        val arr = JSONArray(prefs.getString("old_receipts", "[]") ?: "[]")
        if (arr.length() == 0) { AlertDialog.Builder(this).setTitle("إيصالات الاستلام القديمة").setMessage("لا توجد إيصالات محفوظة خلال آخر 60 يومًا").setPositiveButton("موافق", null).show(); return }
        val entries = (0 until arr.length()).map { arr.getJSONObject(it) }.reversed()
        val labels = entries.map { item ->
            val date = java.text.SimpleDateFormat("yyyy/MM/dd  hh:mm a", java.util.Locale("ar")).format(java.util.Date(item.optLong("timestamp")))
            "${item.optString("supplier")}\n$date"
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("إيصالات الاستلام القديمة")
            .setItems(labels) { _, which -> showReceiptDetails(entries[which]) }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun showReceiptDetails(receipt: JSONObject) {
        val rows = receipt.optJSONArray("rows") ?: JSONArray()
        val lines = StringBuilder("المورد: ${receipt.optString("supplier")}\n")
        lines.append(java.text.SimpleDateFormat("yyyy/MM/dd  HH:mm", java.util.Locale("ar")).format(java.util.Date(receipt.optLong("timestamp")))).append("\n\n")
        for (i in 0 until rows.length()) {
            val r = rows.getJSONObject(i); val unit = r.optString("unit", "قطعة")
            lines.append("${r.optString("name")}  |  ${fmt(r.optDouble("boxes"))} صندوق  |  ${fmt(r.optDouble("factor"))} ×  |  ${fmt(r.optDouble("boxes") * r.optDouble("factor"))} $unit\n")
        }
        val textView = TextView(this).apply { text = lines.toString(); textSize = 15f; setTextColor(Color.BLACK); setPadding(dp(18), dp(12), dp(18), dp(12)); textDirection = View.TEXT_DIRECTION_RTL }
        AlertDialog.Builder(this).setTitle("إيصال استلام - ${receipt.optString("supplier")}").setView(ScrollView(this).apply { addView(textView) })
            .setPositiveButton("PDF") { _, _ -> exportReceiptPdf(receipt) }
            .setNeutralButton("Excel") { _, _ -> exportReceiptExcel(receipt) }
            .setNegativeButton("رجوع") { _, _ -> showOldReceipts() }.show()
    }

    private fun applyAppearance(root: LinearLayout) {
        val bg = screenBg()
        val fg = primaryText()
        root.background = marketBackground()
        fun paint(view: android.view.View) {
            if (view is TextView && view !is Button) view.setTextColor(fg)
            if (view is LinearLayout) for (i in 0 until view.childCount) paint(view.getChildAt(i))
        }
        paint(root)
    }

    private fun confirmDelete(index: Int) {
        AlertDialog.Builder(this).setMessage("حذف الصنف من القائمة؟")
            .setPositiveButton("حذف") { _, _ -> products.removeAt(index); save(); refresh() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun editProduct(index: Int?) {
        val old = index?.let { products[it] }
        val name = field("اسم الصنف", old?.name ?: "")
        val factor = field("العدد داخل الصندوق", old?.factor?.let { if (it == 0.0) "" else fmt(it) } ?: "")
        factor.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        val unit = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("قطعة", "كجم"))
            setSelection(if (old?.unit == "كجم") 1 else 0)
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8))
            addView(label("اسم الصنف").apply { setTextColor(Color.BLACK) }); addView(name); addView(label("العدد داخل الصندوق").apply { setTextColor(Color.BLACK) }); addView(factor)
            addView(label("وحدة القياس").apply { setTextColor(Color.BLACK) }); addView(unit)
        }
        AlertDialog.Builder(this).setTitle(if (old == null) "إضافة صنف" else "تعديل صنف")
            .setView(panel).setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim()
                val f = factor.text.toString().trim().toDoubleOrNull() ?: 0.0
                if (n.isNotEmpty() && f >= 0) {
                    if (old == null) products.add(Product(n, f, 0.0, unit.selectedItem.toString())) else { old.name = n; old.factor = f; old.unit = unit.selectedItem.toString() }
                    save(); refresh()
                } else Toast.makeText(this, "راجع اسم الصنف والعدد داخل الصندوق", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun fmt(v: Double) = if (v % 1.0 == 0.0) v.toLong().toString() else String.format("%.2f", v)

    private fun save() {
        val arr = JSONArray()
        products.forEach { p ->
            arr.put(JSONObject().put("name", p.name).put("factor", p.factor).put("boxes", p.boxes).put("unit", p.unit))
        }
        prefs.edit().putString("products", arr.toString()).apply()
    }

    private fun normalizeName(value: String): String = value.trim().replace(Regex("\\s+"), " ")
        .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")

    // معاملات مستوردة من ملف الأصناف ذي الأربعين صنفًا؛ لا تستبدل أي قيمة أدخلها المستخدم سابقًا.
    private val importedFactors = mapOf(
        "سلق" to 5.0, "نعناع 100 جم - فروتوبيديا" to 20.0, "بروكلي" to 5.0,
        "بروكلي 1 قطعة - فروتوبيديا" to 8.0, "بصل أبيض مقشر" to 10.0,
        "بصل أحمر مقشر" to 10.0, "بقدونس" to 4.0, "بقدونس 100 جم - فروتوبيديا" to 20.0,
        "بنجر" to 10.0, "بنجر 1 ك - فروتوبيديا" to 10.0, "جرجير" to 4.0,
        "جرجير 100 جم - فروتوبيديا" to 20.0, "خس روماني" to 10.0,
        "خس روماني 1 قطعة - فروتوبيديا" to 10.0, "خس صيني (عدد)" to 5.0,
        "خس كابوتشا (عدد)" to 8.0, "خس كابوتشا 1 قطعة - فروتوبيديا" to 8.0,
        "خس لولوبيندا" to 4.0, "خس لولاروسو" to 4.0,
        "خس لولو بيوندا 1 قطعة - فروتوبيديا" to 8.0, "خس لولو روسو 1 قطعة - فروتوبيديا" to 8.0,
        "روزمارى" to 4.0, "ريحان" to 3.0, "زعتر" to 4.0, "سبانخ" to 5.0,
        "سبانخ 500 جم - فروتوبيديا" to 10.0, "شبت" to 4.0, "شبت 100 جم - فروتوبيديا" to 20.0,
        "قرنبيط" to 6.0, "كرات" to 5.0, "كرات بلدي" to 4.0, "كرفس" to 5.0,
        "كرفس 250 جم - فروتوبيديا" to 20.0, "كزنب أبيض" to 2.0, "كزنب أحمر" to 6.0,
        "كزنب ساطه" to 5.0, "كسبرة" to 4.0, "كسبرة 100 جم - فروتوبيديا" to 20.0,
        "ليمون جروس" to 5.0, "نعناع" to 3.0
    ).mapKeys { normalizeName(it.key) }

    private fun load() {
        val raw = prefs.getString("products", null)
        if (raw.isNullOrBlank()) {
            products.clear(); defaultNames.forEach { products.add(Product(it)) }
            applyImportedFactors(); save(); return
        }
        try {
            val arr = JSONArray(raw)
            if (arr.length() == 0) defaultNames.forEach { products.add(Product(it)) }
            else for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                products.add(Product(o.getString("name"), o.optDouble("factor", 0.0), o.optDouble("boxes", 0.0), o.optString("unit", "قطعة")))
            }
            // Migration v1.1 -> v1.2: preserve counts and all non-zero user factors.
            applyImportedFactors(); save()
        } catch (_: Exception) {
            products.clear(); defaultNames.forEach { products.add(Product(it)) }
            applyImportedFactors(); save()
        }
    }

    private fun applyImportedFactors() {
        products.forEach { p ->
            val imported = importedFactors[normalizeName(p.name)]
            if (p.factor == 0.0 && imported != null) p.factor = imported
        }
    }

    @Deprecated("Back navigation confirmation")
    override fun onBackPressed() {
        if (products.any { it.boxes > 0 }) {
            AlertDialog.Builder(this).setTitle("تقفيل غير ممسوح")
                .setMessage("يوجد تقفيل حالي. يمكنك حفظ إيصال استلام أو تصديره PDF أو مسح أعداده من الزر المخصص. الخروج لن يمسح الأرقام، وستظل محفوظة عند فتح التطبيق مرة أخرى.")
                .setPositiveButton("خروج مع الاحتفاظ بالأرقام") { _, _ -> super.onBackPressed() }
                .setNegativeButton("البقاء في التطبيق", null).show()
        } else super.onBackPressed()
    }

    private fun drawArabic(canvas: Canvas, value: String, right: Float, baseline: Float, width: Int, sourcePaint: Paint): Int {
        val tp = TextPaint(sourcePaint)
        val layout = StaticLayout.Builder.obtain(value, 0, value.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false).build()
        canvas.save()
        canvas.translate(right - width, baseline - layout.height + 4f)
        layout.draw(canvas)
        canvas.restore()
        return layout.height
    }

    private val CREATE_PDF = 4102
    private val CREATE_XLSX = 4103
    private var pendingExport: ByteArray? = null
    private var pendingMime = "application/pdf"
    private var pendingName = "إيصال-استلام.pdf"

    private fun currentSnapshot(supplier: String = "") = JSONObject().put("supplier", supplier)
        .put("timestamp", System.currentTimeMillis()).put("report_name", prefs.getString("report_name", "") ?: "")
        .put("rows", JSONArray().also { a -> products.filter { it.boxes > 0 }.forEach { a.put(JSONObject().put("name", it.name).put("factor", it.factor).put("boxes", it.boxes).put("unit", it.unit)) } })

    private fun exportPdf() {
        if (products.none { it.boxes > 0 }) { Toast.makeText(this, "لا توجد أصناف مسجلة في التقفيل", Toast.LENGTH_SHORT).show(); return }
        exportReceiptPdf(currentSnapshot())
    }
    private fun exportExcel() {
        if (products.none { it.boxes > 0 }) { Toast.makeText(this, "لا توجد أصناف مسجلة في التقفيل", Toast.LENGTH_SHORT).show(); return }
        exportReceiptExcel(currentSnapshot())
    }

    private fun exportReceiptPdf(receipt: JSONObject) {
        try {
            val rows = receipt.optJSONArray("rows") ?: JSONArray()
            val doc = PdfDocument(); val pageWidth = 595; val pageHeight = 842
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textAlign = Paint.Align.RIGHT }
            val perPage = 15; val pages = maxOf(1, (rows.length() + perPage - 1) / perPage)
            var grandBoxes = 0.0; var grandPieces = 0.0; var grandKg = 0.0
            for (i in 0 until rows.length()) { val r = rows.getJSONObject(i); val q = r.optDouble("boxes") * r.optDouble("factor"); grandBoxes += r.optDouble("boxes"); if (r.optString("unit", "قطعة") == "كجم") grandKg += q else grandPieces += q }
            for (pg in 0 until pages) {
                val page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pg + 1).create()); val c = page.canvas
                paint.textSize = 20f; drawArabic(c, "رصيف الاستلام", 555f, 42f, 260, paint)
                paint.textSize = 16f; drawArabic(c, "إيصال استلام", 555f, 70f, 260, paint)
                paint.textSize = 12f
                drawArabic(c, "المورد: ${receipt.optString("supplier")}", 555f, 94f, 300, paint)
                drawArabic(c, java.text.SimpleDateFormat("yyyy/MM/dd  HH:mm", java.util.Locale("ar")).format(java.util.Date(receipt.optLong("timestamp"))), 555f, 116f, 300, paint)
                val reportBy = receipt.optString("report_name")
                if (reportBy.isNotBlank()) drawArabic(c, "إعداد: $reportBy", 555f, 138f, 300, paint)
                val top = 170f
                paint.color = 0xFFE9E1D2.toInt(); c.drawRect(35f, top - 20, 560f, top + 5, paint); paint.color = Color.BLACK
                paint.textSize = 11f
                drawArabic(c, "اسم الصنف", 550f, top, 155, paint); drawArabic(c, "معامل الصندوق", 380f, top, 100, paint)
                drawArabic(c, "الصناديق", 250f, top, 85, paint); drawArabic(c, "الإجمالي", 135f, top, 85, paint); drawArabic(c, "الوحدة", 55f, top, 55, paint)
                var y = top + 32f
                val from = pg * perPage; val to = minOf(rows.length(), from + perPage)
                for (i in from until to) {
                    val r = rows.getJSONObject(i); val b = r.optDouble("boxes"); val f = r.optDouble("factor"); val u = r.optString("unit", "قطعة")
                    paint.textSize = 10.5f; val nameHeight = drawArabic(c, r.optString("name"), 550f, y, 155, paint)
                    paint.textSize = 11f; c.drawText(fmt(f), 380f, y, paint); c.drawText(fmt(b), 250f, y, paint); c.drawText(fmt(b*f), 135f, y, paint)
                    drawArabic(c, u, 55f, y, 55, paint)
                    val rowHeight = maxOf(30f, nameHeight + 8f)
                    c.drawLine(35f, y + rowHeight - 5f, 560f, y + rowHeight - 5f, Paint().apply { color = 0xFFCCCCCC.toInt(); strokeWidth = 0.6f })
                    y += rowHeight
                }
                if (pg == pages-1) {
                    y += 28f; paint.textSize = 12f; drawArabic(c, "إجمالي الصناديق: ${fmt(grandBoxes)}", 555f, y, 300, paint)
                    drawArabic(c, "إجمالي القطع: ${fmt(grandPieces)} قطعة", 555f, y+24, 300, paint)
                    drawArabic(c, "إجمالي الوزن: ${fmt(grandKg)} كجم", 555f, y+48, 300, paint)
                }
                paint.textAlign = Paint.Align.LEFT; paint.textSize = 10f; c.drawText("${pg+1} / $pages", 40f, 815f, paint); paint.textAlign = Paint.Align.RIGHT
                doc.finishPage(page)
            }
            val out = ByteArrayOutputStream(); doc.writeTo(out); doc.close()
            pendingExport = out.toByteArray(); pendingMime = "application/pdf"; pendingName = "إيصال-استلام-${receipt.optString("supplier", "")}.pdf"; launchExportPicker(CREATE_PDF)
        } catch (_: Exception) { Toast.makeText(this, "تعذر تجهيز PDF", Toast.LENGTH_SHORT).show() }
    }

    private fun exportReceiptExcel(receipt: JSONObject) {
        try {
            val rows = receipt.optJSONArray("rows") ?: JSONArray()
            val sheet = StringBuilder()
            fun inlineCell(ref: String, value: String, style: Int = 0) = "<c r=\"$ref\" t=\"inlineStr\" s=\"$style\"><is><t>${xmlEscape(value)}</t></is></c>"
            fun numberCell(ref: String, value: Double) = "<c r=\"$ref\" s=\"2\"><v>$value</v></c>"
            fun row(n: Int, cells: String) = "<row r=\"$n\">$cells</row>"
            sheet.append(row(1, inlineCell("A1", "رصيف الاستلام", 1)))
            sheet.append(row(2, inlineCell("A2", "إيصال استلام - ${receipt.optString("supplier")}")))
            sheet.append(row(3, inlineCell("A3", java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale("ar")).format(java.util.Date(receipt.optLong("timestamp"))))))
            sheet.append(row(4, inlineCell("A4", "اسم الصنف", 1)+inlineCell("B4", "معامل الصندوق", 1)+inlineCell("C4", "عدد الصناديق", 1)+inlineCell("D4", "الإجمالي", 1)+inlineCell("E4", "الوحدة", 1)))
            var totalBoxes = 0.0; var pieces = 0.0; var kg = 0.0
            for (i in 0 until rows.length()) {
                val r = rows.getJSONObject(i); val b = r.optDouble("boxes"); val f = r.optDouble("factor"); val u = r.optString("unit", "قطعة"); val n = i+5
                sheet.append(row(n, inlineCell("A$n", r.optString("name"))+numberCell("B$n", f)+numberCell("C$n", b)+numberCell("D$n", b*f)+inlineCell("E$n", u)))
                totalBoxes += b; if (u == "كجم") kg += b*f else pieces += b*f
            }
            val endRow = rows.length()+5
            sheet.append(row(endRow, inlineCell("A$endRow", "إجمالي الصناديق")+numberCell("B$endRow", totalBoxes)))
            sheet.append(row(endRow+1, inlineCell("A${endRow+1}", "إجمالي القطع")+numberCell("B${endRow+1}", pieces)))
            sheet.append(row(endRow+2, inlineCell("A${endRow+2}", "إجمالي الوزن كجم")+numberCell("B${endRow+2}", kg)))
            val sheetXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols><col min=\"1\" max=\"1\" width=\"34\" customWidth=\"1\"/><col min=\"2\" max=\"5\" width=\"18\" customWidth=\"1\"/></cols><sheetViews><sheetView workbookViewId=\"0\" rightToLeft=\"1\"/></sheetViews><sheetData>$sheet</sheetData></worksheet>"
            val workbook = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"إيصال الاستلام\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
            val styles = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Arial\"/></font><font><b/><sz val=\"14\"/><name val=\"Arial\"/></font></fonts><fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE9E1D2\"/><bgColor indexed=\"64\"/></patternFill></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"3\"><xf xfId=\"0\"/><xf xfId=\"0\" fontId=\"1\" fillId=\"1\" applyFont=\"1\" applyFill=\"1\"/><xf xfId=\"0\" numFmtId=\"2\" applyNumberFormat=\"1\"/></cellXfs></styleSheet>"
            val entries = linkedMapOf(
                "[Content_Types].xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>",
                "_rels/.rels" to "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>",
                "xl/workbook.xml" to workbook,
                "xl/_rels/workbook.xml.rels" to "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>",
                "xl/worksheets/sheet1.xml" to sheetXml,
                "xl/styles.xml" to styles
            )
            val out = ByteArrayOutputStream(); ZipOutputStream(out).use { zip -> entries.forEach { (name, content) -> zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry() } }
            pendingExport = out.toByteArray(); pendingMime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; pendingName = "إيصال-استلام-${receipt.optString("supplier", "")}.xlsx"; launchExportPicker(CREATE_XLSX)
        } catch (_: Exception) { Toast.makeText(this, "تعذر تجهيز ملف Excel", Toast.LENGTH_SHORT).show() }
    }
    private fun xmlEscape(v: String) = v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
    private fun launchExportPicker(code: Int) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = pendingMime; putExtra(Intent.EXTRA_TITLE, pendingName) }
        startActivityForResult(intent, code)
    }

    @Deprecated("Android document picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if ((requestCode == CREATE_PDF || requestCode == CREATE_XLSX) && resultCode == RESULT_OK) {
            val uri = data?.data; val bytes = pendingExport
            if (uri != null && bytes != null) try {
                contentResolver.openOutputStream(uri)?.use { it.write(bytes); it.flush() }
                Toast.makeText(this, "تم حفظ الملف بنجاح", Toast.LENGTH_LONG).show()
            } catch (_: Exception) { Toast.makeText(this, "تعذر حفظ الملف", Toast.LENGTH_SHORT).show() }
        }
        pendingExport = null
    }
}
